// popup.ts
var GG_ORIGIN_KEY = "gg-origin";
var GG_ORIGIN_DEFAULT = "https://80-208-224-130.sslip.io";
var statusEl = document.getElementById("status");
async function getOrigin() {
  const s = await chrome.storage.local.get(GG_ORIGIN_KEY);
  return s[GG_ORIGIN_KEY] || GG_ORIGIN_DEFAULT;
}
async function checkSession() {
  try {
    const origin = await getOrigin();
    const r = await fetch(`${origin}/api/groups`, { credentials: "include" });
    if (r.ok) {
      statusEl.textContent = "\u2713 Connected to GG";
      statusEl.className = "ok";
    } else if (r.status === 401) {
      statusEl.textContent = "\xD7 Not signed in \u2014 open GG and log in.";
      statusEl.className = "err";
    } else {
      statusEl.textContent = `\xD7 GG returned HTTP ${r.status}`;
      statusEl.className = "err";
    }
  } catch (err) {
    statusEl.textContent = `\xD7 ${err?.message || "Cannot reach GG"}`;
    statusEl.className = "err";
  }
}
document.getElementById("open-gg").addEventListener("click", async () => {
  const origin = await getOrigin();
  chrome.tabs.create({ url: origin });
});
document.getElementById("reset-proxy").addEventListener("click", async () => {
  await chrome.proxy.settings.clear({ scope: "regular" });
  chrome.runtime.sendMessage({ type: "reset-proxy" });
  statusEl.textContent = "\u2713 Proxy reset \u2014 reload Discord tab";
  statusEl.className = "ok";
});
document.getElementById("open-options").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});
void checkSession();
