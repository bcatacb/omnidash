// content-script.ts
console.log("[GG Account Switcher] content script loaded on", location.host);
