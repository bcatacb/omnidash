// extension/background.ts
var cache = /* @__PURE__ */ new Map();
var CACHE_TTL_MS = 5 * 60 * 1e3;
var GG_ORIGIN_KEY = "gg-origin";
var GG_ORIGIN_DEFAULT = "https://gg.linktree.bond";
async function getGgOrigin() {
  const stored = await chrome.storage.local.get(GG_ORIGIN_KEY);
  return stored[GG_ORIGIN_KEY] || GG_ORIGIN_DEFAULT;
}
async function fetchBundle(groupId, originOverride) {
  const now = Date.now();
  const cached = cache.get(groupId);
  if (cached && now - cached.cachedAtMs < CACHE_TTL_MS) return cached.bundle;
  const origin = originOverride || await getGgOrigin();
  const r = await fetch(`${origin}/api/groups/${encodeURIComponent(groupId)}/token-bundle`, {
    credentials: "include",
    cache: "no-store"
  });
  if (!r.ok) throw new Error(`fetch ${groupId} token bundle: HTTP ${r.status} (are you logged into gg?)`);
  const bundle = await r.json();
  cache.set(groupId, { bundle, cachedAtMs: now });
  return bundle;
}
async function findOrCreateDiscordTab() {
  const tabs = await chrome.tabs.query({ url: "https://discord.com/*" });
  if (tabs.length > 0) return tabs[0];
  return await chrome.tabs.create({ url: "https://discord.com/channels/@me", active: true });
}
async function writeTokenAndReload(tabId, token, navigateChannelId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: async (t) => {
      const log = (...a) => console.log("[gg-ext]", ...a);
      try {
        const iframe = document.createElement("iframe");
        iframe.style.display = "none";
        document.body.appendChild(iframe);
        const ls = iframe.contentWindow?.localStorage;
        if (ls) {
          ls.setItem("token", JSON.stringify(t));
          ls.setItem("hideAppInstallNotice", "true");
          ls.setItem("DESKTOP_APP_NUDGE_SEEN", "true");
          ls.setItem("APP_NUDGE_LAST_DISMISSED", String(Date.now()));
          log("token written via iframe");
        } else {
          throw new Error("iframe has no localStorage");
        }
        iframe.remove();
      } catch (e) {
        console.warn("[gg-ext] iframe write failed, falling back to direct:", e);
        try {
          localStorage.setItem("token", JSON.stringify(t));
          localStorage.setItem("hideAppInstallNotice", "true");
        } catch {
        }
      }
      try {
        if (typeof indexedDB.databases === "function") {
          const dbs = await indexedDB.databases();
          for (const db of dbs) {
            if (db?.name) {
              try {
                indexedDB.deleteDatabase(db.name);
              } catch {
              }
            }
          }
          log(`cleared ${dbs.length} indexedDB databases`);
        }
      } catch (e) {
        console.warn("[gg-ext] indexedDB clear failed:", e);
      }
      try {
        if (typeof caches !== "undefined") {
          const keys = await caches.keys();
          for (const k of keys) await caches.delete(k);
          log(`cleared ${keys.length} cache stores`);
        }
      } catch (e) {
        console.warn("[gg-ext] caches clear failed:", e);
      }
    },
    args: [token]
  });
  if (navigateChannelId && /^\d+$/.test(navigateChannelId)) {
    await reloadThenSpaNavigate(tabId, navigateChannelId);
  } else {
    await chrome.tabs.reload(tabId);
  }
}
var HUB_URL = "https://discord.com/channels/@me";
async function reloadThenSpaNavigate(tabId, channelId) {
  const tab = await chrome.tabs.get(tabId);
  const currentUrl = (tab.url || "").split("#")[0].replace(/\/$/, "");
  const atHub = currentUrl === HUB_URL;
  await new Promise((resolve) => {
    let done = false;
    const finish = async () => {
      if (done) return;
      done = true;
      chrome.tabs.onUpdated.removeListener(listener);
      clearTimeout(timeout);
      await new Promise((r) => setTimeout(r, 1500));
      try {
        await chrome.scripting.executeScript({
          target: { tabId },
          func: (id) => {
            try {
              history.pushState({}, "", `/channels/@me/${id}`);
              window.dispatchEvent(new PopStateEvent("popstate", { state: {} }));
            } catch (e) {
              console.error("[gg-ext] pushState failed", e);
            }
          },
          args: [channelId]
        });
      } catch (e) {
        console.warn("[bg] pushState injection failed:", e);
      }
      resolve();
    };
    const listener = (updatedTabId, changeInfo) => {
      if (updatedTabId !== tabId) return;
      if (changeInfo.status === "complete") void finish();
    };
    chrome.tabs.onUpdated.addListener(listener);
    const timeout = setTimeout(() => void finish(), 12e3);
    if (atHub) {
      void chrome.tabs.reload(tabId);
    } else {
      void chrome.tabs.update(tabId, { url: HUB_URL, active: true });
    }
  });
}
var currentProxyAuth = null;
function parseProxyUrl(url) {
  try {
    const u = new URL(url);
    const scheme = u.protocol === "https:" ? "https" : "http";
    const port = Number(u.port) || (scheme === "https" ? 443 : 80);
    return {
      scheme,
      host: u.hostname,
      port,
      username: decodeURIComponent(u.username || ""),
      password: decodeURIComponent(u.password || "")
    };
  } catch {
    return null;
  }
}
async function setActiveProxy(proxyUrl) {
  if (!proxyUrl) {
    currentProxyAuth = null;
    await chrome.proxy.settings.clear({ scope: "regular" });
    console.log("[bg] proxy cleared \u2014 using browser default route");
    return;
  }
  const parsed = parseProxyUrl(proxyUrl);
  if (!parsed) {
    console.warn("[bg] unparseable proxy url, leaving previous proxy in place");
    return;
  }
  currentProxyAuth = { username: parsed.username, password: parsed.password };
  await chrome.proxy.settings.set({
    scope: "regular",
    value: {
      mode: "fixed_servers",
      rules: {
        singleProxy: { scheme: parsed.scheme, host: parsed.host, port: parsed.port },
        // bypassList values are space- or comma-separated host patterns. <local>
        // is the magic value for any plain hostname (localhost, gg-api, etc).
        bypassList: ["<local>", "gg.linktree.bond"]
      }
    }
  });
  console.log(`[bg] proxy set to ${parsed.scheme}://${parsed.host}:${parsed.port} (bypass gg.linktree.bond + <local>)`);
}
chrome.webRequest.onAuthRequired.addListener(
  (details, callback) => {
    if (!details.isProxy || !currentProxyAuth) {
      if (callback) callback({});
      return;
    }
    if (callback) callback({ authCredentials: currentProxyAuth });
  },
  { urls: ["<all_urls>"] },
  ["asyncBlocking"]
);
async function openDmsInDiscordTab(tabId, recipients) {
  if (!recipients.length) return { opened: 0, failed: 0 };
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: async (recipientList) => {
      let token = null;
      try {
        const iframe = document.createElement("iframe");
        iframe.style.display = "none";
        document.body.appendChild(iframe);
        const ls = iframe.contentWindow?.localStorage;
        const raw = ls?.getItem("token");
        iframe.remove();
        if (!raw) return { error: "no token in localStorage" };
        token = raw.startsWith('"') ? JSON.parse(raw) : raw;
      } catch (e) {
        return { error: "token read failed: " + (e?.message || String(e)) };
      }
      let primaryChannelId;
      let opened = 0;
      let failed = 0;
      for (let i = 0; i < recipientList.length; i++) {
        const recipient = recipientList[i];
        try {
          const r = await fetch("https://discord.com/api/v9/users/@me/channels", {
            method: "POST",
            headers: {
              authorization: token,
              "content-type": "application/json"
            },
            body: JSON.stringify({ recipients: [recipient] })
          });
          if (!r.ok) {
            failed += 1;
            console.warn(`[gg-ext] DM-open failed recipient=${recipient} HTTP ${r.status}`);
          } else {
            const j = await r.json().catch(() => ({}));
            const channelId = String(j?.id || "");
            if (i === 0) primaryChannelId = channelId;
            opened += 1;
          }
        } catch (e) {
          failed += 1;
          console.warn(`[gg-ext] DM-open threw recipient=${recipient}`, e);
        }
        if (i < recipientList.length - 1) {
          await new Promise((r) => setTimeout(r, 700));
        }
      }
      return { primaryChannelId, opened, failed };
    },
    args: [recipients]
  });
  return results[0]?.result || { opened: 0, failed: 0 };
}
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const apiOrigin = sender.origin || void 0;
  (async () => {
    try {
      if (msg.type === "activate") {
        const bundle = await fetchBundle(msg.groupId, apiOrigin);
        const entry = bundle.entries.find((e) => e.accountId === msg.accountId);
        if (!entry) {
          sendResponse({ ok: false, error: "account not in group bundle" });
          return;
        }
        const tab = await findOrCreateDiscordTab();
        if (!tab.id) {
          sendResponse({ ok: false, error: "no discord tab id" });
          return;
        }
        await setActiveProxy(entry.proxyUrl);
        await writeTokenAndReload(tab.id, entry.token, msg.navigateChannelId);
        sendResponse({ ok: true, accountId: msg.accountId, username: entry.username, proxy: entry.proxyUrl ? "set" : "direct", navigated: !!msg.navigateChannelId });
        return;
      }
      if (msg.type === "prepare-and-open") {
        const bundle = await fetchBundle(msg.groupId, apiOrigin);
        const entry = bundle.entries.find((e) => e.accountId === msg.accountId);
        if (!entry) {
          sendResponse({ ok: false, error: "account not in group bundle" });
          return;
        }
        const tab = await findOrCreateDiscordTab();
        if (!tab.id) {
          sendResponse({ ok: false, error: "no discord tab id" });
          return;
        }
        await setActiveProxy(entry.proxyUrl);
        await writeTokenAndReload(tab.id, entry.token);
        await new Promise((r) => setTimeout(r, 1800));
        const pendingFromBundle = Array.isArray(entry.pendingRecipientIds) ? entry.pendingRecipientIds.slice() : [];
        const dedup = /* @__PURE__ */ new Set();
        const ordered = [];
        for (const r of [msg.recipientDiscordUserId, ...pendingFromBundle]) {
          if (!r || dedup.has(r)) continue;
          dedup.add(r);
          ordered.push(r);
        }
        const batch = await openDmsInDiscordTab(tab.id, ordered);
        if (!batch.primaryChannelId) {
          console.warn(`[bg] prepare-and-open batch failed: ${batch.error || "no primary channel"}`);
          sendResponse({ ok: false, error: batch.error || "DM batch open failed" });
          return;
        }
        console.log(`[bg] prepare-and-open batch ok acct=${msg.accountId} opened=${batch.opened} failed=${batch.failed} primary=${batch.primaryChannelId}`);
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: (id) => {
              try {
                history.pushState({}, "", `/channels/@me/${id}`);
                window.dispatchEvent(new PopStateEvent("popstate", { state: {} }));
              } catch (e) {
                console.error("[gg-ext] pushState failed", e);
              }
            },
            args: [batch.primaryChannelId]
          });
        } catch (e) {
          console.warn("[bg] post-open pushState failed:", e);
        }
        sendResponse({ ok: true, channelId: batch.primaryChannelId, opened: batch.opened, failed: batch.failed, accountId: msg.accountId, username: entry.username });
        return;
      }
      sendResponse({ ok: false, error: "unknown message type" });
    } catch (err) {
      sendResponse({ ok: false, error: err?.message || String(err) });
    }
  })();
  return true;
});
chrome.runtime.onMessageExternal.addListener((msg, _sender, sendResponse) => {
  (async () => {
    try {
      if (msg.type === "ping") {
        sendResponse({ ok: true, version: chrome.runtime.getManifest().version });
        return;
      }
      if (msg.type === "activate") {
        const bundle = await fetchBundle(msg.groupId);
        const entry = bundle.entries.find((e) => e.accountId === msg.accountId);
        if (!entry) {
          sendResponse({ ok: false, error: "account not in group bundle" });
          return;
        }
        const tab = await findOrCreateDiscordTab();
        if (!tab.id) {
          sendResponse({ ok: false, error: "no discord tab id" });
          return;
        }
        await setActiveProxy(entry.proxyUrl);
        await writeTokenAndReload(tab.id, entry.token, msg.navigateChannelId);
        sendResponse({ ok: true, accountId: msg.accountId, username: entry.username, proxy: entry.proxyUrl ? "set" : "direct", navigated: !!msg.navigateChannelId });
        return;
      }
      if (msg.type === "prepare-and-open") {
        const bundle = await fetchBundle(msg.groupId);
        const entry = bundle.entries.find((e) => e.accountId === msg.accountId);
        if (!entry) {
          sendResponse({ ok: false, error: "account not in group bundle" });
          return;
        }
        const tab = await findOrCreateDiscordTab();
        if (!tab.id) {
          sendResponse({ ok: false, error: "no discord tab id" });
          return;
        }
        await setActiveProxy(entry.proxyUrl);
        await writeTokenAndReload(tab.id, entry.token);
        await new Promise((r) => setTimeout(r, 1800));
        const pendingFromBundle = Array.isArray(entry.pendingRecipientIds) ? entry.pendingRecipientIds.slice() : [];
        const dedup = /* @__PURE__ */ new Set();
        const ordered = [];
        for (const r of [msg.recipientDiscordUserId, ...pendingFromBundle]) {
          if (!r || dedup.has(r)) continue;
          dedup.add(r);
          ordered.push(r);
        }
        const batch = await openDmsInDiscordTab(tab.id, ordered);
        if (!batch.primaryChannelId) {
          console.warn(`[bg] prepare-and-open batch failed: ${batch.error || "no primary channel"}`);
          sendResponse({ ok: false, error: batch.error || "DM batch open failed" });
          return;
        }
        console.log(`[bg] prepare-and-open batch ok acct=${msg.accountId} opened=${batch.opened} failed=${batch.failed} primary=${batch.primaryChannelId}`);
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: (id) => {
              try {
                history.pushState({}, "", `/channels/@me/${id}`);
                window.dispatchEvent(new PopStateEvent("popstate", { state: {} }));
              } catch (e) {
                console.error("[gg-ext] pushState failed", e);
              }
            },
            args: [batch.primaryChannelId]
          });
        } catch (e) {
          console.warn("[bg] post-open pushState failed:", e);
        }
        sendResponse({
          ok: true,
          channelId: batch.primaryChannelId,
          opened: batch.opened,
          failed: batch.failed,
          accountId: msg.accountId,
          username: entry.username
        });
        return;
      }
      sendResponse({ ok: false, error: "unknown message type" });
    } catch (err) {
      sendResponse({ ok: false, error: err?.message || String(err) });
    }
  })();
  return true;
});
