// extension/popup.ts
var statusEl = document.getElementById("status");
async function checkSession() {
  try {
    const { "gg-origin": origin = "https://gg.linktree.bond" } = await chrome.storage.local.get("gg-origin");
    const r = await fetch(`${origin}/api/groups`, { credentials: "include" });
    if (r.ok) {
      statusEl.textContent = "\u2713 Connected to gg.linktree.bond";
      statusEl.className = "ok";
    } else if (r.status === 401) {
      statusEl.textContent = "\xD7 Not logged into gg \u2014 open it and sign in.";
      statusEl.className = "err";
    } else {
      statusEl.textContent = `\xD7 gg HTTP ${r.status}`;
      statusEl.className = "err";
    }
  } catch (err) {
    statusEl.textContent = `\xD7 ${err?.message || "fetch failed"}`;
    statusEl.className = "err";
  }
}
document.getElementById("open-gg").addEventListener("click", async (e) => {
  e.preventDefault();
  const { "gg-origin": origin = "https://gg.linktree.bond" } = await chrome.storage.local.get("gg-origin");
  chrome.tabs.create({ url: origin });
});
document.getElementById("open-options").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});
void checkSession();
